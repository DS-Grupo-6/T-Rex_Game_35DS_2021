using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Girlfriend : MonoBehaviour
{
    public GameObject aperteE;
    public GameObject dialogo;
    public GameObject coracao;
    public bool colisaoNPC = false;
    public bool boxDialogo = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Dialogo();
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        // Se o player encostou no npc
        if((collider.gameObject.layer == 10)&&(!boxDialogo))
        {
            aperteE.SetActive(true);
            colisaoNPC = true;
        }
    }

    private void Dialogo()
    {
        if(Input.GetKeyDown(KeyCode.E)){
            if(colisaoNPC){
                aperteE.SetActive(false);
                colisaoNPC = false;
                dialogo.SetActive(true);
                coracao.SetActive(true);
                boxDialogo = true;
            }
            else{
                dialogo.SetActive(false);
                coracao.SetActive(false);
                boxDialogo = false;
            }
            
        }
    }
}
