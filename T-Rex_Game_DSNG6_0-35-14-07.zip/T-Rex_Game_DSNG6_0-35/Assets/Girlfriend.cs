using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Girlfriend : MonoBehaviour
{
    public GameObject Aperte;
    // Start is called before the first frame update
    void Start()
    {
        Aperte = GetComponent<GameObject>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        // Se o player encostou no npc
        if(collider.gameObject.layer == 10)
        {
            //Aperte.SetActive(false);
        }
        
    }
}
